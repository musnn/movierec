# # import requests

# # just = requests.get("http://api.gowatchit.com/api/v2/search/ranked/:title")
# # print(just)

# # response = requests.post('https://httpbin.org/post', data = {'key':'value'})
# # # Update an existing resource
# # requests.put('https://httpbin.org/put', data = {'key':'value'})
# # print(response.headers["date"])

# import config # to hide TMDB API keys
# import requests # to make TMDB API calls
# import locale # to format currency as USD
# locale.setlocale( locale.LC_ALL, '' )

# import pandas as pd
# import matplotlib
# import matplotlib.pyplot as plt
# from matplotlib.ticker import FuncFormatter # to format currency on charts axis

# api_key = config.tmdb_api_key # get TMDB API key from config.py file

# response = requests.get('https://api.themoviedb.org/3/discover/movie?api_key=' +  api_key + '&primary_release_year=2017&sort_by=revenue.desc')

# highest_revenue = response.json() # store parsed json response

# # uncomment the next line to get a peek at the highest_revenue json structure
# # highest_revenue

# highest_revenue_films = highest_revenue['results']

# # define column names for our new dataframe
# columns = ['film', 'revenue']

# # create dataframe with film and revenue columns
# df = pd.DataFrame(columns=columns)

# # for each of the highest revenue films make an api call for that specific movie to return the budget and revenue
# for film in highest_revenue_films:
#     # print(film['title'])
#     film_revenue = requests.get('https://api.themoviedb.org/3/movie/'+ str(film['id']) +'?api_key='+ api_key+'&language=en-US')
#     film_revenue = film_revenue.json()
#     #print(locale.currency(film_revenue['revenue'], grouping=True ))
#     df.loc[len(df)]=[film['title'],film_revenue['revenue']] # store title and revenue in our dataframe    

# import imdb

# movies_database = imdb.IMDb()
# print(dir(movies_database))

import json, requests

response = requests.get("http://www.omdbapi.com/?apikey=56c81ae&t=doctor-strange")
python_dictionary_values = json.loads(response.text)
print(python_dictionary_values)

print(response)
