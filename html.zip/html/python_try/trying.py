
from urllib.request import Request, urlopen

request = Request('http://api.gowatchit.com/api/v2/search/ranked/:the-avengers')

response_body = urlopen(request).read()
print(response_body)